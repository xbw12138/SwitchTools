SwLink sysmodule 安装说明
=========================

作用:SwLink sysmodule 让电脑能通过 USB 直接读写 Switch 的 SD 卡。
没有它,swlink-cli / SwLink.app 都会提示「未找到 Switch 设备 16C0:27DA」。

安装步骤
--------
1. 把压缩包里的 atmosphere 文件夹解压到 SD 卡根目录
   (最终路径为 SD:/atmosphere/contents/00FF0000A53B5A57/)

2. 确认该目录下存在三个文件:
   - exefs.nsp
   - toolbox.json
   - flags/boot2.flag      (空文件,存在即开机自启)

3. 重启 Switch,或在 Tesla 菜单的 Sysmodules 里启用 SwLink

4. 用数据线连接电脑,swlink-cli 即可识别设备

目录示意
--------
SD:/
└── atmosphere/
    └── contents/
        └── 00FF0000A53B5A57/
            ├── exefs.nsp
            ├── toolbox.json
            └── flags/
                └── boot2.flag

注意
----
- 需要 Atmosphere 自制系统。
- 连接失败时先确认线缆支持数据传输(不是只能充电的线)。
- SwLink.app 与 swlink-cli 不能同时占用设备,会提示设备被占用。
